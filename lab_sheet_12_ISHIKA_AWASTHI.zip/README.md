# BTCS303T Full Stack Coding Assessment — Complete Solutions

This package contains four independent solutions corresponding to the uploaded assessment:

1. `problem1-secure-task-api/` — Node.js + Express + bcrypt + JWT secure task API.
2. `problem2-sql/answers.sql` — SQL analytics and concurrency answers.
3. `problem3-react-product-search/` — React product search/cart SPA.
4. `problem4-git-ci/` — GitHub Actions CI workflow and Git recovery commands.

The assessment specifies a 2-hour, 10-mark coding assessment and requires the Problem 1 server to start on port 3000 and export the Express app for tests. Problem 3 requires the listed `data-testid` hooks. Problem 4 requires lint-before-test and a deploy job only after successful tests on pushes to main.

## Important
Problem 2(c) intentionally separates the conditional stock UPDATE from the application-level row-count check because SQL dialects differ in how procedural IF/ROLLBACK logic is expressed. Problem 3 includes a runnable local mock; replace only `fetchProducts` with the assessment-provided mock when it is supplied by the evaluator.
