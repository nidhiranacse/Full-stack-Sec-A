# Problem 2 — SQL Analytics and Concurrency

`answers.sql` contains all three requested answers. Part (c) uses PostgreSQL-style `EXTRACT(MONTH FROM ...)` and a parameterized transaction. The key concurrency protection is the conditional stock UPDATE: the database locks the row while changing it, and the application rolls back if no row is affected.
