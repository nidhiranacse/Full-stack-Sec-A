-- P2(a) Top 3 products by revenue within each category, including ties.
WITH product_revenue AS (
    SELECT
        p.id,
        p.name,
        p.category,
        SUM(p.price * oi.qty) AS revenue
    FROM products p
    JOIN order_items oi ON oi.product_id = p.id
    JOIN orders o ON o.id = oi.order_id
    GROUP BY p.id, p.name, p.category
), ranked AS (
    SELECT *,
           DENSE_RANK() OVER (
               PARTITION BY category
               ORDER BY revenue DESC
           ) AS revenue_rank
    FROM product_revenue
)
SELECT id, name, category, revenue, revenue_rank
FROM ranked
WHERE revenue_rank <= 3
ORDER BY category, revenue_rank, name;

-- P2(b) Customers with at least one order in every month Jan-Mar 2025.
SELECT c.id, c.name, c.city
FROM customers c
JOIN orders o ON o.customer_id = c.id
WHERE o.order_date >= '2025-01-01'
  AND o.order_date <  '2025-04-01'
GROUP BY c.id, c.name, c.city
HAVING COUNT(DISTINCT EXTRACT(MONTH FROM o.order_date)) = 3;

-- P2(c) Atomic stock reservation + order insertion.
-- PostgreSQL-style transaction. The UPDATE itself locks the product row.
BEGIN;

UPDATE products
SET stock = stock - :qty
WHERE id = :product_id
  AND stock >= :qty;

-- Application checks that the UPDATE affected exactly 1 row.
-- If 0 rows were affected: ROLLBACK and report insufficient stock/product missing.
-- Otherwise insert the order and order-item rows, then COMMIT.

INSERT INTO orders (id, customer_id, order_date)
VALUES (:order_id, :customer_id, CURRENT_TIMESTAMP);

INSERT INTO order_items (order_id, product_id, qty)
VALUES (:order_id, :product_id, :qty);

COMMIT;

-- If the stock UPDATE affected 0 rows, execute ROLLBACK instead.
-- A plain SELECT followed by UPDATE is unsafe because two concurrent requests
-- can read the same stock before either UPDATE occurs, causing overselling.
