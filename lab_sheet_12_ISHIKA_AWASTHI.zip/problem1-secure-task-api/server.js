require('dotenv').config();
const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();
app.use(express.json());

const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) throw new Error('JWT_SECRET environment variable is required');

const users = new Map();
const tasks = new Map();
let nextUserId = 1;
let nextTaskId = 1;
const failedLogins = new Map();

function validEmail(email) { return typeof email === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email); }
function validPassword(password) { return typeof password === 'string' && password.length >= 6; }
function validStatus(status) { return ['todo', 'doing', 'done'].includes(status); }

function auth(req, res, next) {
  const header = req.get('authorization') || '';
  const [scheme, token] = header.split(' ');
  if (scheme !== 'Bearer' || !token) return res.status(401).json({ error: 'Authentication required' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

function loginRecord(email) {
  const now = Date.now();
  const record = failedLogins.get(email);
  if (!record || now - record.windowStart >= 60000) {
    const fresh = { windowStart: now, failures: 0 };
    failedLogins.set(email, fresh);
    return fresh;
  }
  return record;
}

app.post('/auth/register', async (req, res) => {
  const { email, password, role = 'user' } = req.body || {};
  if (!validEmail(email) || !validPassword(password) || !['user', 'admin'].includes(role)) {
    return res.status(400).json({ error: 'Valid email, password (6+ chars), and role user/admin are required' });
  }
  if (users.has(email.toLowerCase())) return res.status(409).json({ error: 'Email already exists' });
  const passwordHash = await bcrypt.hash(password, 10);
  const user = { id: String(nextUserId++), email: email.toLowerCase(), passwordHash, role };
  users.set(user.email, user);
  return res.status(201).json({ id: user.id, email: user.email, role: user.role });
});

app.post('/auth/login', async (req, res) => {
  const email = typeof req.body?.email === 'string' ? req.body.email.toLowerCase() : '';
  const password = req.body?.password;
  const record = loginRecord(email);
  if (record.failures >= 5) {
    const retryAfter = Math.max(1, Math.ceil((record.windowStart + 60000 - Date.now()) / 1000));
    res.set('Retry-After', String(retryAfter));
    return res.status(429).json({ error: 'Too many failed login attempts' });
  }
  const user = users.get(email);
  const ok = user && typeof password === 'string' && await bcrypt.compare(password, user.passwordHash);
  if (!ok) {
    record.failures += 1;
    return res.status(401).json({ error: 'Wrong credentials' });
  }
  failedLogins.delete(email);
  const token = jwt.sign({ sub: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '15m' });
  return res.json({ token });
});

app.post('/tasks', auth, (req, res) => {
  const { title, status } = req.body || {};
  if (typeof title !== 'string' || !title.trim() || !validStatus(status)) {
    return res.status(400).json({ error: 'title and valid status (todo, doing, done) are required' });
  }
  const task = { id: String(nextTaskId++), ownerId: req.user.sub, title: title.trim(), status };
  tasks.set(task.id, task);
  return res.status(201).json(task);
});

app.get('/tasks', auth, (req, res) => {
  const status = req.query.status;
  if (status !== undefined && !validStatus(status)) return res.status(400).json({ error: 'Invalid status' });
  const page = Math.max(1, Number.parseInt(req.query.page || '1', 10));
  const limit = Math.min(100, Math.max(1, Number.parseInt(req.query.limit || '10', 10)));
  if (!Number.isFinite(page) || !Number.isFinite(limit)) return res.status(400).json({ error: 'Invalid pagination' });
  let data = [...tasks.values()].filter(t => t.ownerId === req.user.sub);
  if (status) data = data.filter(t => t.status === status);
  const total = data.length;
  data = data.slice((page - 1) * limit, page * limit);
  return res.json({ data, page, total });
});

function canModify(task, user) { return task.ownerId === user.sub || user.role === 'admin'; }

app.patch('/tasks/:id', auth, (req, res) => {
  const task = tasks.get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Task not found' });
  if (!canModify(task, req.user)) return res.status(403).json({ error: 'Forbidden' });
  const { title, status } = req.body || {};
  if (title !== undefined && (typeof title !== 'string' || !title.trim())) return res.status(400).json({ error: 'Invalid title' });
  if (status !== undefined && !validStatus(status)) return res.status(400).json({ error: 'Invalid status' });
  if (title !== undefined) task.title = title.trim();
  if (status !== undefined) task.status = status;
  return res.json(task);
});

app.delete('/tasks/:id', auth, (req, res) => {
  const task = tasks.get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Task not found' });
  if (!canModify(task, req.user)) return res.status(403).json({ error: 'Forbidden' });
  tasks.delete(req.params.id);
  return res.status(204).send();
});

app.get('/health', (_req, res) => res.json({ ok: true }));

if (require.main === module) app.listen(PORT, () => console.log(`Server listening on http://localhost:${PORT}`));
module.exports = { app, users, tasks, failedLogins };
