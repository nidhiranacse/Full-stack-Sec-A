# Problem 1 — Secure Task Manager API

## Setup
```bash
npm install
copy .env.example .env   # Windows
# or cp .env.example .env
npm start
```

Set `JWT_SECRET` in `.env`. Server runs on port 3000.

## Endpoints
- POST `/auth/register` — `{email,password,role?}`
- POST `/auth/login` — `{email,password}`; JWT expires in 15 minutes
- POST `/tasks` — Bearer token; `{title,status}`
- GET `/tasks?status=&page=&limit=` — caller's tasks only
- PATCH `/tasks/:id` — owner/admin
- DELETE `/tasks/:id` — owner/admin

The login limiter keeps failed attempts per email in a one-minute window. The sixth failed attempt and attempts during the lockout return `429` with `Retry-After`. Authentication is centralized in reusable middleware and malformed JWTs are caught without crashing the server.
