import React, { createContext, useContext, useEffect, useReducer, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

const PRODUCTS = Array.from({length: 42}, (_, i) => ({id: i+1, name: ['Laptop','Phone','Keyboard','Mouse','Monitor','Headphones'][i%6] + ` Model ${i+1}`, price: [499,799,49,29,249,99][i%6]}));

// Replace this mock with the assessment's provided fetchProducts(query, page).
export function fetchProducts(query, page) {
  return new Promise(resolve => {
    const delay = 100 + Math.random() * 700;
    setTimeout(() => {
      const q = query.trim().toLowerCase();
      const filtered = PRODUCTS.filter(p => p.name.toLowerCase().includes(q));
      const pageSize = 6;
      resolve({ products: filtered.slice((page-1)*pageSize, page*pageSize), total: filtered.length, pageSize });
    }, delay);
  });
}

const CartContext = createContext(null);
const initialCart = () => {
  try { return JSON.parse(localStorage.getItem('quick-cart') || '{}'); } catch { return {}; }
};
function reducer(state, action) {
  const next = {...state};
  switch(action.type) {
    case 'ADD': next[action.product.id] = {...action.product, qty: (next[action.product.id]?.qty || 0) + 1}; return next;
    case 'INC': if (next[action.id]) next[action.id] = {...next[action.id], qty: next[action.id].qty + 1}; return next;
    case 'DEC': if (next[action.id]) { const qty = next[action.id].qty - 1; if (qty <= 0) delete next[action.id]; else next[action.id] = {...next[action.id], qty}; } return next;
    case 'REMOVE': delete next[action.id]; return next;
    default: return state;
  }
}
function CartProvider({children}) {
  const [cart, dispatch] = useReducer(reducer, undefined, initialCart);
  useEffect(() => localStorage.setItem('quick-cart', JSON.stringify(cart)), [cart]);
  return <CartContext.Provider value={{cart, dispatch}}>{children}</CartContext.Provider>;
}
const useCart = () => useContext(CartContext);

function App() {
  const [query,setQuery] = useState(''); const [page,setPage] = useState(1); const [result,setResult] = useState({products:[],total:0,pageSize:6}); const [loading,setLoading] = useState(false); const [error,setError] = useState('');
  const {cart,dispatch} = useCart();
  useEffect(() => {
    const controller = new AbortController(); const timer = setTimeout(async () => {
      setLoading(true); setError('');
      try {
        const response = await fetchProducts(query,page);
        if (!controller.signal.aborted) setResult(response);
      } catch(e) { if (!controller.signal.aborted) setError('Could not load products'); }
      finally { if (!controller.signal.aborted) setLoading(false); }
    }, 300);
    return () => { clearTimeout(timer); controller.abort(); };
  }, [query,page]);
  const changeQuery = e => { setQuery(e.target.value); setPage(1); };
  const items = Object.values(cart); const total = items.reduce((s,p)=>s+p.price*p.qty,0); const hasNext = page * result.pageSize < result.total;
  return <div className="app">
    <header><h1>Product Search</h1><div className="cart-summary">Cart: {items.reduce((s,p)=>s+p.qty,0)} items</div></header>
    <input data-testid="search-input" value={query} onChange={changeQuery} placeholder="Search products..." />
    {loading && <p className="state">Loading...</p>}
    {!loading && error && <p className="state error">{error}</p>}
    {!loading && !error && result.products.length===0 && <p className="state">No results</p>}
    <main>{result.products.map(p=><article data-testid="product-item" key={p.id}><h2>{p.name}</h2><p>${p.price}</p><button data-testid="add-btn" onClick={()=>dispatch({type:'ADD',product:p})}>Add to cart</button></article>)}</main>
    <nav><button data-testid="prev-btn" disabled={page===1} onClick={()=>setPage(p=>p-1)}>Previous</button><span>Page {page}</span><button data-testid="next-btn" disabled={!hasNext} onClick={()=>setPage(p=>p+1)}>Next</button></nav>
    <section className="cart"><h2>Cart</h2>{items.map(p=><div className="cart-row" key={p.id}><span>{p.name}</span><button onClick={()=>dispatch({type:'DEC',id:p.id})}>−</button><span>{p.qty}</span><button onClick={()=>dispatch({type:'INC',id:p.id})}>+</button><button onClick={()=>dispatch({type:'REMOVE',id:p.id})}>Remove</button></div>)}<strong data-testid="cart-total">Cart total: ${total.toFixed(2)}</strong></section>
  </div>;
}
createRoot(document.getElementById('root')).render(<CartProvider><App/></CartProvider>);
