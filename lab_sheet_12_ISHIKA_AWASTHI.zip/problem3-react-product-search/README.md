# Problem 3 — React Product Search with Cart

## Run
```bash
npm install
npm run dev
```

The provided mock `fetchProducts(query, page)` is represented locally so the app is runnable. In the assessment environment, replace the mock implementation with the supplied function without changing the component logic.

Implementation points: 300ms debounce with cleanup, request cancellation via AbortController, page reset on query change, reducer + Context for cart state, localStorage persistence, loading/empty states, pagination, and required `data-testid` hooks.
