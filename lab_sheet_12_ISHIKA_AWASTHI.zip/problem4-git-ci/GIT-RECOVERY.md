# Problem 4(b) — Safely Recover Lost Commits

1. Fetch all remote references:
```bash
git fetch --all --prune
```

2. Inspect the local reflog for the old main tip and the missing commits:
```bash
git reflog --all --date=local
git log --all --graph --oneline --decorate
```

3. Once the missing commit SHA is identified, create a recovery branch before changing main:
```bash
git switch -c recovery <missing-sha>
```

4. Verify the recovered history:
```bash
git log --oneline --decorate --graph
```

5. Push the recovery branch so the commits are safely stored on the remote:
```bash
git push -u origin recovery
```

6. After review, restore main using a normal PR/merge. If the required restoration is specifically to move main back to the recovered tip, do it through the protected-branch workflow rather than another force push.

## Prevention
Enable branch protection/rulesets on `main`, block force pushes, and require pull requests. This prevents a teammate from rewriting shared main history directly.
