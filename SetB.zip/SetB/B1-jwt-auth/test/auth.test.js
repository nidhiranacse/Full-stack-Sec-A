const test = require("node:test");
const assert = require("node:assert");
const jwt = require("jsonwebtoken");
const app = require("../server");

let server, base;
test.before(async () => {
  await new Promise((r) => {
    server = app.listen(0, r);
  });
  base = `http://localhost:${server.address().port}`;
});
test.after(() => server.close());

const post = (path, body) =>
  fetch(base + path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

test("register validation and success", async () => {
  let r = await post("/register", { username: "", password: "abcdef" });
  assert.strictEqual(r.status, 400);
  assert.deepStrictEqual(await r.json(), { error: "Invalid input" });
  r = await post("/register", { username: "a", password: "123" });
  assert.strictEqual(r.status, 400);
  r = await post("/register", { password: "abcdef" });
  assert.strictEqual(r.status, 400);
  r = await post("/register", { username: "alice", password: "secret1" });
  assert.strictEqual(r.status, 201);
  assert.deepStrictEqual(await r.json(), { message: "User registered" });
  r = await post("/register", { username: "alice", password: "secret1" });
  assert.strictEqual(r.status, 409);
  assert.deepStrictEqual(await r.json(), { error: "Username already exists" });
});

test("login, profile and token failures", async () => {
  await post("/register", { username: "bob", password: "secret1" });
  let r = await post("/login", { username: "bob", password: "wrong" });
  assert.strictEqual(r.status, 401);
  assert.deepStrictEqual(await r.json(), { error: "Invalid credentials" });
  r = await post("/login", { username: "nobody", password: "secret1" });
  assert.strictEqual(r.status, 401);

  r = await post("/login", { username: "bob", password: "secret1" });
  assert.strictEqual(r.status, 200);
  const { token } = await r.json();
  const decoded = jwt.decode(token);
  assert.strictEqual(decoded.username, "bob");
  assert.strictEqual(decoded.exp - decoded.iat, 3600);

  r = await fetch(base + "/profile", { headers: { Authorization: `Bearer ${token}` } });
  assert.strictEqual(r.status, 200);
  assert.deepStrictEqual(await r.json(), { username: "bob" });

  const bad = [undefined, "Bearer abc.def.ghi", `Bearer ${token}x`, token];
  for (const h of bad) {
    r = await fetch(base + "/profile", { headers: h ? { Authorization: h } : {} });
    assert.strictEqual(r.status, 401);
    assert.deepStrictEqual(await r.json(), { error: "Unauthorized" });
  }

  const expired = jwt.sign({ username: "bob" }, "dev-secret-change-me", { expiresIn: -10 });
  r = await fetch(base + "/profile", { headers: { Authorization: `Bearer ${expired}` } });
  assert.strictEqual(r.status, 401);
});
