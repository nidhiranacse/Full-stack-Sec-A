const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
app.use(express.json());

const JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";

// In-memory user store: username -> { username, passwordHash }
const users = new Map();

app.post("/register", (req, res) => {
  const { username, password } = req.body || {};
  if (
    typeof username !== "string" ||
    username.trim() === "" ||
    typeof password !== "string" ||
    password.length < 6
  ) {
    return res.status(400).json({ error: "Invalid input" });
  }
  if (users.has(username)) {
    return res.status(409).json({ error: "Username already exists" });
  }
  users.set(username, {
    username,
    passwordHash: bcrypt.hashSync(password, 8),
  });
  return res.status(201).json({ message: "User registered" });
});

app.post("/login", (req, res) => {
  const { username, password } = req.body || {};
  const user = typeof username === "string" ? users.get(username) : undefined;
  if (
    !user ||
    typeof password !== "string" ||
    !bcrypt.compareSync(password, user.passwordHash)
  ) {
    return res.status(401).json({ error: "Invalid credentials" });
  }
  const token = jwt.sign({ username: user.username }, JWT_SECRET, {
    expiresIn: "1h",
  });
  return res.status(200).json({ token });
});

function auth(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  const token = header.slice(7).trim();
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    return next();
  } catch (e) {
    return res.status(401).json({ error: "Unauthorized" });
  }
}

app.get("/profile", auth, (req, res) => {
  return res.status(200).json({ username: req.user.username });
});

module.exports = app;

if (require.main === module) {
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
}
