import React from "react";
import { createRoot } from "react-dom/client";
import Cart from "./Cart.jsx";

const products = [
  { id: 1, name: "Notebook", price: 50 },
  { id: 2, name: "Pen Set", price: 20 },
  { id: 3, name: "Backpack", price: 600 },
  { id: 4, name: "Headphones", price: 400 },
];

createRoot(document.getElementById("root")).render(<Cart products={products} />);
