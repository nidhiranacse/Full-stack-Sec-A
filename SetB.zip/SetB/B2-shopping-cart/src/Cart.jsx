import React, { useState } from "react";

// Discount rule: 10% off when the cart total reaches the threshold.
// (Change these two constants if your lab sheet specifies a different rule.)
const DISCOUNT_THRESHOLD = 1000;
const DISCOUNT_RATE = 0.1;

export default function Cart({ products = [] }) {
  // cart: array of { id, qty }, kept in the order items were first added
  const [cart, setCart] = useState([]);

  const addToCart = (id) => {
    setCart((prev) =>
      prev.some((l) => l.id === id)
        ? prev.map((l) => (l.id === id ? { ...l, qty: l.qty + 1 } : l))
        : [...prev, { id, qty: 1 }]
    );
  };

  const increase = (id) =>
    setCart((prev) => prev.map((l) => (l.id === id ? { ...l, qty: l.qty + 1 } : l)));

  // Decreasing below 1 removes the line
  const decrease = (id) =>
    setCart((prev) =>
      prev
        .map((l) => (l.id === id ? { ...l, qty: l.qty - 1 } : l))
        .filter((l) => l.qty > 0)
    );

  const remove = (id) => setCart((prev) => prev.filter((l) => l.id !== id));

  const lines = cart
    .map((l) => ({ ...l, product: products.find((p) => p.id === l.id) }))
    .filter((l) => l.product);

  const total = lines.reduce((sum, l) => sum + l.product.price * l.qty, 0);
  const hasDiscount = total >= DISCOUNT_THRESHOLD;
  const discount = hasDiscount ? total * DISCOUNT_RATE : 0;
  const grandTotal = total - discount;

  return (
    <div style={{ fontFamily: "sans-serif", maxWidth: 600, margin: "1rem auto" }}>
      <h2>Products</h2>
      <ul>
        {products.map((p) => (
          <li key={p.id}>
            {p.name} - {p.price}{" "}
            <button data-testid={`add-${p.id}`} onClick={() => addToCart(p.id)}>
              Add
            </button>
          </li>
        ))}
      </ul>

      <h2>Cart</h2>
      {lines.length === 0 ? (
        <p data-testid="cart-empty">Cart is empty</p>
      ) : (
        <ul>
          {lines.map(({ id, qty, product }) => (
            <li key={id}>
              {product.name} ({product.price}){" "}
              <button data-testid={`dec-${id}`} onClick={() => decrease(id)}>
                -
              </button>{" "}
              <span data-testid={`qty-${id}`}>{qty}</span>{" "}
              <button data-testid={`inc-${id}`} onClick={() => increase(id)}>
                +
              </button>{" "}
              <button data-testid={`remove-${id}`} onClick={() => remove(id)}>
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}

      {lines.length > 0 && (
        <div>
          <p data-testid="total">Total: {total.toFixed(2)}</p>
          {hasDiscount && (
            <>
              <p data-testid="discount">Discount: {discount.toFixed(2)}</p>
              <p data-testid="grand-total">Grand Total: {grandTotal.toFixed(2)}</p>
            </>
          )}
        </div>
      )}
    </div>
  );
}
