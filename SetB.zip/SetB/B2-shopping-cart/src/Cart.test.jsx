import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { describe, it, expect } from "vitest";
import Cart from "./Cart.jsx";

const products = [
  { id: 1, name: "A", price: 50 },
  { id: 2, name: "B", price: 60 },
  { id: 3, name: "C", price: 500 },
];
const click = (id) => fireEvent.click(screen.getByTestId(id));

describe("Cart", () => {
  it("shows empty state", () => {
    render(<Cart products={products} />);
    expect(screen.getByTestId("cart-empty")).toHaveTextContent("Cart is empty");
    expect(screen.queryByTestId("discount")).toBeNull();
  });

  it("adds, increases, decreases, removes and totals", () => {
    render(<Cart products={products} />);
    click("add-1");
    click("add-1");
    click("add-2");
    expect(screen.getByTestId("qty-1")).toHaveTextContent("2");
    expect(screen.getByTestId("total")).toHaveTextContent("Total: 160.00");
    click("inc-2");
    expect(screen.getByTestId("total")).toHaveTextContent("Total: 220.00");
    click("dec-1");
    expect(screen.getByTestId("qty-1")).toHaveTextContent("1");
    click("remove-2");
    expect(screen.queryByTestId("qty-2")).toBeNull();
    click("dec-1");
    expect(screen.getByTestId("cart-empty")).toBeInTheDocument();
  });

  it("applies discount automatically", () => {
    render(<Cart products={products} />);
    click("add-3");
    click("add-3");
    expect(screen.getByTestId("total")).toHaveTextContent("Total: 1000.00");
    expect(screen.getByTestId("discount")).toHaveTextContent("Discount: 100.00");
    expect(screen.getByTestId("grand-total")).toHaveTextContent("Grand Total: 900.00");
    click("dec-3");
    expect(screen.queryByTestId("discount")).toBeNull();
  });
});
