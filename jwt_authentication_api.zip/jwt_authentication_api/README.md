# Practical B1: JWT Authentication API

A simple Node.js + Express API implementing user registration, login, JWT authentication, and a protected profile route.

## Requirements
- Node.js and npm installed

## Setup
Open a terminal in this folder and run:

```bash
npm install
npm start
```

The server runs at `http://localhost:3000`.

## API endpoints

### 1. Register
`POST http://localhost:3000/register`

Body (JSON):
```json
{
  "username": "vazi",
  "password": "vazi123"
}
```

Success: `201`
```json
{ "message": "User registered" }
```

Invalid input: `400`
```json
{ "error": "Invalid input" }
```

Duplicate username: `409`
```json
{ "error": "Username already exists" }
```

### 2. Login
`POST http://localhost:3000/login`

Body (JSON):
```json
{
  "username": "vazi",
  "password": "vazi123"
}
```

Success: `200`, returns a JWT token that expires in one hour:
```json
{ "token": "<jwt>" }
```

Invalid credentials: `401`
```json
{ "error": "Invalid credentials" }
```

### 3. Profile
`GET http://localhost:3000/profile`

Add header:
`Authorization: Bearer <token>`

Valid token: `200`
```json
{ "username": "vazi" }
```

Missing, malformed, invalid, or expired token: `401`
```json
{ "error": "Unauthorized" }
```

## Test with curl

Register:
```bash
curl -X POST http://localhost:3000/register -H "Content-Type: application/json" -d "{\"username\":\"vazi\",\"password\":\"vazi123\"}"
```

Login:
```bash
curl -X POST http://localhost:3000/login -H "Content-Type: application/json" -d "{\"username\":\"vazi\",\"password\":\"vazi123\"}"
```

Then copy the token from the login response and use it:
```bash
curl http://localhost:3000/profile -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

## Notes
- User data is stored in memory and is cleared when the server restarts.
- Passwords are stored as plain text only to keep this educational practical short. Do not use this approach in production.
- For production, hash passwords, use a persistent database, and set a strong `JWT_SECRET` environment variable.
