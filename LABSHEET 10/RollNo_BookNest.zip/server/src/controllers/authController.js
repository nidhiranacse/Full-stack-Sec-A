const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { AppError } = require('../utils/errors');

function createAuthController(db) {
  const findMember = db.prepare(
    'SELECT id, name, email, password_hash, role FROM members WHERE email = ?'
  );

  function login(req, res, next) {
    const { email, password } = req.body || {};
    if (typeof email !== 'string' || typeof password !== 'string' || !email.trim() || !password) {
      return next(new AppError(400, 'VALIDATION_ERROR', 'Email and password are required.'));
    }

    const member = findMember.get(email.trim().toLowerCase());
    if (!member || !bcrypt.compareSync(password, member.password_hash)) {
      return next(new AppError(401, 'INVALID_CREDENTIALS', 'Email or password is incorrect.'));
    }

    const token = jwt.sign(
      { id: member.id, role: member.role },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );
    return res.json({
      token,
      user: { id: member.id, name: member.name, email: member.email, role: member.role }
    });
  }

  return { login };
}

module.exports = { createAuthController };
