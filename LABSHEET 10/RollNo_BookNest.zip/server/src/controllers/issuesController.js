const { AppError } = require('../utils/errors');
const { calculateFine } = require('../utils/fines');

function createIssuesController(db) {
  const hasMember = db.prepare('SELECT id FROM members WHERE id = ? AND role = ?');
  const hasBook = db.prepare('SELECT id FROM books WHERE id = ?');
  const activeCount = db.prepare('SELECT COUNT(*) AS count FROM issues WHERE member_id = ? AND returned_on IS NULL');
  const reserveCopy = db.prepare(
    'UPDATE books SET available_copies = available_copies - 1 WHERE id = ? AND available_copies > 0'
  );
  const createIssue = db.prepare(
    'INSERT INTO issues (member_id, book_id, issued_on, due_on) VALUES (?, ?, ?, ?)'
  );
  const getIssue = db.prepare('SELECT id, book_id, due_on, returned_on FROM issues WHERE id = ?');
  const markReturned = db.prepare(
    'UPDATE issues SET returned_on = ?, fine = ? WHERE id = ? AND returned_on IS NULL'
  );
  const restoreCopy = db.prepare('UPDATE books SET available_copies = available_copies + 1 WHERE id = ?');
  const issueTransaction = db.transaction((memberId, bookId, issuedOn, dueOn) => {
    if (!hasMember.get(memberId, 'member')) {
      throw new AppError(404, 'MEMBER_NOT_FOUND', 'Member was not found.');
    }
    if (!hasBook.get(bookId)) {
      throw new AppError(404, 'BOOK_NOT_FOUND', 'Book was not found.');
    }
    if (activeCount.get(memberId).count >= 3) {
      throw new AppError(409, 'LIMIT_REACHED', 'A member may hold at most 3 active issues.');
    }
    if (reserveCopy.run(bookId).changes !== 1) {
      throw new AppError(409, 'NO_COPIES', 'No copies of this book are currently available.');
    }
    const result = createIssue.run(memberId, bookId, issuedOn, dueOn);
    return Number(result.lastInsertRowid);
  });
  const returnTransaction = db.transaction((issueId, returnedOn) => {
    const issue = getIssue.get(issueId);
    if (!issue) throw new AppError(404, 'ISSUE_NOT_FOUND', 'Issue was not found.');
    if (issue.returned_on) {
      throw new AppError(409, 'ALREADY_RETURNED', 'This issue has already been returned.');
    }
    const fine = calculateFine(issue.due_on, returnedOn);
    if (markReturned.run(returnedOn, fine, issueId).changes !== 1) {
      throw new AppError(409, 'ALREADY_RETURNED', 'This issue has already been returned.');
    }
    restoreCopy.run(issue.book_id);
    return fine;
  });

  function issueBook(req, res, next) {
    const { memberId, bookId } = req.body || {};
    if (!Number.isInteger(memberId) || memberId < 1 || !Number.isInteger(bookId) || bookId < 1) {
      return next(new AppError(400, 'VALIDATION_ERROR', 'memberId and bookId must be positive whole numbers.'));
    }
    const issued = new Date();
    const due = new Date(issued);
    due.setDate(due.getDate() + 14);
    const dateOnly = (date) => date.toISOString().slice(0, 10);
    try {
      const id = issueTransaction.immediate(memberId, bookId, dateOnly(issued), dateOnly(due));
      return res.status(201).json({
        id,
        memberId,
        bookId,
        issuedOn: dateOnly(issued),
        dueOn: dateOnly(due),
        returnedOn: null,
        fine: 0
      });
    } catch (err) {
      if (err instanceof AppError) return next(err);
      return next(err);
    }
  }

  function returnBook(req, res, next) {
    const issueId = Number(req.params.id);
    if (!Number.isInteger(issueId) || issueId < 1) {
      return next(new AppError(404, 'ISSUE_NOT_FOUND', 'Issue was not found.'));
    }
    try {
      const fine = returnTransaction.immediate(issueId, new Date().toISOString().slice(0, 10));
      return res.json({ fine });
    } catch (err) {
      return next(err);
    }
  }

  function getOverdue(req, res) {
    const issues = db.prepare(`
      SELECT i.id, m.name AS memberName, m.email AS memberEmail, b.title AS bookTitle,
             b.code AS bookCode, i.issued_on AS issuedOn, i.due_on AS dueOn,
             CAST(julianday(date('now')) - julianday(i.due_on) AS INTEGER) AS daysOverdue,
             CAST(julianday(date('now')) - julianday(i.due_on) AS INTEGER) * 2 AS fine
      FROM issues i
      JOIN members m ON m.id = i.member_id
      JOIN books b ON b.id = i.book_id
      WHERE i.returned_on IS NULL AND date(i.due_on) < date('now')
      ORDER BY i.due_on, i.id
    `).all();
    return res.json(issues);
  }

  function getMine(req, res) {
    const issues = db.prepare(`
      SELECT i.id, b.code AS bookCode, b.title AS bookTitle, b.author,
             i.issued_on AS issuedOn, i.due_on AS dueOn, i.returned_on AS returnedOn,
             i.fine, CASE WHEN i.returned_on IS NULL THEN MAX(
               0, CAST(julianday(date('now')) - julianday(i.due_on) AS INTEGER)
             ) * 2 ELSE i.fine END AS currentFine
      FROM issues i JOIN books b ON b.id = i.book_id
      WHERE i.member_id = ?
      ORDER BY i.id DESC
    `).all(req.user.id);
    return res.json(issues);
  }

  function getMembers(req, res) {
    return res.json(db.prepare(
      "SELECT id, name, email FROM members WHERE role = 'member' ORDER BY name"
    ).all());
  }

  return { issueBook, returnBook, getOverdue, getMine, getMembers };
}

module.exports = { createIssuesController };
