const { AppError } = require('../utils/errors');

function createBooksController(db) {
  const listBooks = db.prepare(`
    SELECT id, code, title, author, total_copies AS totalCopies,
           available_copies AS availableCopies
    FROM books
    WHERE instr(lower(title), lower(?)) > 0 OR instr(lower(author), lower(?)) > 0
    ORDER BY id
    LIMIT ? OFFSET ?
  `);
  const countBooks = db.prepare(`
    SELECT COUNT(*) AS total
    FROM books
    WHERE instr(lower(title), lower(?)) > 0 OR instr(lower(author), lower(?)) > 0
  `);
  const addBook = db.prepare(
    'INSERT INTO books (code, title, author, total_copies, available_copies) VALUES (?, ?, ?, ?, ?)'
  );

  function getBooks(req, res) {
    const search = typeof req.query.search === 'string' ? req.query.search.trim() : '';
    const pageValue = Number(req.query.page ?? 1);
    const limitValue = Number(req.query.limit ?? 10);
    const page = Number.isInteger(pageValue) && pageValue > 0 ? pageValue : 1;
    const limit = Number.isInteger(limitValue) && limitValue > 0 ? Math.min(limitValue, 50) : 10;
    const total = countBooks.get(search, search).total;
    const totalPages = Math.ceil(total / limit);
    return res.json({
      data: listBooks.all(search, search, limit, (page - 1) * limit),
      page,
      limit,
      total,
      totalPages
    });
  }

  function createBook(req, res, next) {
    const { code, title, author, totalCopies } = req.body || {};
    if (
      typeof code !== 'string' || !code.trim() ||
      typeof title !== 'string' || !title.trim() ||
      typeof author !== 'string' || !author.trim() ||
      !Number.isInteger(totalCopies) || totalCopies < 0
    ) {
      return next(new AppError(400, 'VALIDATION_ERROR', 'Provide a code, title, author, and non-negative whole-number totalCopies.'));
    }
    try {
      const result = addBook.run(code.trim(), title.trim(), author.trim(), totalCopies, totalCopies);
      return res.status(201).json({
        id: result.lastInsertRowid,
        code: code.trim(),
        title: title.trim(),
        author: author.trim(),
        totalCopies,
        availableCopies: totalCopies
      });
    } catch (err) {
      if (err.code === 'SQLITE_CONSTRAINT_UNIQUE') {
        return next(new AppError(409, 'DUPLICATE_BOOK', 'A book with that code already exists.'));
      }
      return next(err);
    }
  }

  return { getBooks, createBook };
}

module.exports = { createBooksController };
