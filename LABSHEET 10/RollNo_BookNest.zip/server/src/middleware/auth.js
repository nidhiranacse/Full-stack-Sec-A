const jwt = require('jsonwebtoken');
const { AppError } = require('../utils/errors');

function authenticate(req, res, next) {
  const header = req.get('authorization');
  if (!header || !header.startsWith('Bearer ')) {
    return next(new AppError(401, 'UNAUTHORIZED', 'Authentication is required.'));
  }

  try {
    req.user = jwt.verify(header.slice(7), process.env.JWT_SECRET);
    return next();
  } catch {
    return next(new AppError(401, 'UNAUTHORIZED', 'Your session is invalid or expired.'));
  }
}

function requireRole(role) {
  return (req, res, next) => {
    if (req.user.role !== role) {
      return next(new AppError(403, 'FORBIDDEN', 'You do not have permission to do that.'));
    }
    return next();
  };
}

module.exports = { authenticate, requireRole };
