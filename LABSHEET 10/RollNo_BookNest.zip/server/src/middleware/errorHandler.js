const { AppError } = require('../utils/errors');

function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);
  const status = err instanceof AppError ? err.status : 500;
  const code = err instanceof AppError ? err.code : 'INTERNAL_ERROR';
  const message = err instanceof AppError ? err.message : 'An unexpected error occurred.';
  if (status === 500) console.error(err);
  res.status(status).json({ error: { code, message } });
}

module.exports = { errorHandler };
