function calculateFine(dueOn, returnedOn) {
  const due = new Date(`${dueOn}T00:00:00Z`);
  const returned = new Date(`${returnedOn}T00:00:00Z`);
  const daysLate = Math.max(0, Math.floor((returned - due) / 86400000));
  return daysLate * 2;
}

module.exports = { calculateFine };
