const { calculateFine } = require('./fines');

describe('calculateFine', () => {
  test('charges nothing when returned on time', () => {
    expect(calculateFine('2026-10-14', '2026-10-14')).toBe(0);
  });

  test('charges ₹2 for one full day late', () => {
    expect(calculateFine('2026-10-14', '2026-10-15')).toBe(2);
  });

  test('charges ₹20 for ten full days late', () => {
    expect(calculateFine('2026-10-04', '2026-10-14')).toBe(20);
  });
});
