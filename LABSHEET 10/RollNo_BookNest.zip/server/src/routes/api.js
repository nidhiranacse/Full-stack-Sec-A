const express = require('express');
const { createAuthController } = require('../controllers/authController');
const { createBooksController } = require('../controllers/booksController');
const { createIssuesController } = require('../controllers/issuesController');
const { authenticate, requireRole } = require('../middleware/auth');

function createApiRouter(db) {
  const router = express.Router();
  const auth = createAuthController(db);
  const books = createBooksController(db);
  const issues = createIssuesController(db);

  router.post('/auth/login', auth.login);
  router.get('/books', authenticate, books.getBooks);
  router.post('/books', authenticate, requireRole('librarian'), books.createBook);
  router.post('/issues', authenticate, requireRole('librarian'), issues.issueBook);
  router.post('/issues/:id/return', authenticate, requireRole('librarian'), issues.returnBook);
  router.get('/issues/overdue', authenticate, requireRole('librarian'), issues.getOverdue);
  router.get('/members', authenticate, requireRole('librarian'), issues.getMembers);
  router.get('/issues/mine', authenticate, requireRole('member'), issues.getMine);
  return router;
}

module.exports = { createApiRouter };
