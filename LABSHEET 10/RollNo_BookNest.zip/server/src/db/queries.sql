-- Q1: Overdue, unreturned loans; days overdue and accrued fine.
SELECT m.name AS member_name, b.title AS book_title,
       CAST(julianday(date('now')) - julianday(i.due_on) AS INTEGER) AS days_overdue,
       CAST(julianday(date('now')) - julianday(i.due_on) AS INTEGER) * 2 AS fine
FROM issues i
JOIN members m ON m.id = i.member_id
JOIN books b ON b.id = i.book_id
WHERE i.returned_on IS NULL AND date(i.due_on) < date('now')
ORDER BY i.due_on, i.id;

-- Q2: The three most-issued books (including current and returned loans).
SELECT b.id, b.code, b.title, COUNT(i.id) AS times_issued
FROM books b
LEFT JOIN issues i ON i.book_id = b.id
GROUP BY b.id, b.code, b.title
ORDER BY times_issued DESC, b.id
LIMIT 3;
