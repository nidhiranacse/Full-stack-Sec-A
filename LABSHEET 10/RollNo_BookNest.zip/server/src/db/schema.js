const fs = require('node:fs');
const path = require('node:path');

const schema = `
  PRAGMA foreign_keys = ON;
  CREATE TABLE IF NOT EXISTS members (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('librarian', 'member'))
  );
  CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY,
    code TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    author TEXT NOT NULL,
    total_copies INTEGER NOT NULL CHECK (total_copies >= 0),
    available_copies INTEGER NOT NULL CHECK (
      available_copies >= 0 AND available_copies <= total_copies
    )
  );
  CREATE TABLE IF NOT EXISTS issues (
    id INTEGER PRIMARY KEY,
    member_id INTEGER NOT NULL REFERENCES members(id),
    book_id INTEGER NOT NULL REFERENCES books(id),
    issued_on TEXT NOT NULL,
    due_on TEXT NOT NULL,
    returned_on TEXT,
    fine INTEGER NOT NULL DEFAULT 0 CHECK (fine >= 0)
  );
  CREATE INDEX IF NOT EXISTS idx_issues_member_returned
    ON issues(member_id, returned_on);
`;

function initializeDatabase(db) {
  db.exec(schema);
}

function openDatabase(dbPath) {
  if (dbPath !== ':memory:') {
    fs.mkdirSync(path.dirname(path.resolve(dbPath)), { recursive: true });
  }
  const Database = require('better-sqlite3');
  const db = new Database(dbPath);
  db.pragma('foreign_keys = ON');
  db.pragma('journal_mode = WAL');
  initializeDatabase(db);
  return db;
}

module.exports = { initializeDatabase, openDatabase };
