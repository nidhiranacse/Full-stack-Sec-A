const path = require('node:path');
require('dotenv').config({ path: path.resolve(__dirname, '../../../.env') });
const bcrypt = require('bcryptjs');
const { openDatabase } = require('./schema');

const dbPath = process.env.DB_PATH || path.join(__dirname, '../../data/booknest.sqlite');
const db = openDatabase(dbPath);
const hash = bcrypt.hashSync('Pass@123', 10);

const seed = db.transaction(() => {
  db.prepare('DELETE FROM issues').run();
  db.prepare('DELETE FROM books').run();
  db.prepare('DELETE FROM members').run();

  const addMember = db.prepare(
    'INSERT INTO members (id, name, email, password_hash, role) VALUES (?, ?, ?, ?, ?)'
  );
  [
    [1, 'Admin', 'admin@lib.example', hash, 'librarian'],
    [2, 'Aarav', 'aarav@lib.example', hash, 'member'],
    [3, 'Meera', 'meera@lib.example', hash, 'member'],
    [4, 'Rohan', 'rohan@lib.example', hash, 'member']
  ].forEach((member) => addMember.run(...member));

  const addBook = db.prepare(
    'INSERT INTO books (id, code, title, author, total_copies, available_copies) VALUES (?, ?, ?, ?, ?, ?)'
  );
  [
    [1, 'LIB-1001', 'The Pragmatic Programmer', 'Hunt & Thomas', 2, 2],
    [2, 'LIB-1002', 'Clean Code', 'Robert C. Martin', 1, 1],
    [3, 'LIB-1003', 'Operating System Concepts', 'Silberschatz', 3, 3],
    [4, 'LIB-1004', 'Database System Concepts', 'Silberschatz', 1, 0],
    [5, 'LIB-1005', 'Computer Networks', 'Tanenbaum', 2, 2]
  ].forEach((book) => addBook.run(...book));

  const today = new Date();
  const issued = new Date(today);
  issued.setDate(issued.getDate() - 20);
  const due = new Date(today);
  due.setDate(due.getDate() - 6);
  const dateOnly = (date) => date.toISOString().slice(0, 10);
  db.prepare(
    'INSERT INTO issues (id, member_id, book_id, issued_on, due_on) VALUES (1, 4, 4, ?, ?)'
  ).run(dateOnly(issued), dateOnly(due));
});

try {
  seed();
  console.log(`BookNest database seeded at ${dbPath}`);
} finally {
  db.close();
}
