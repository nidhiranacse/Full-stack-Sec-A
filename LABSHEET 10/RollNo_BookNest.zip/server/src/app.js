const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const { openDatabase } = require('./db/schema');
const { createApiRouter } = require('./routes/api');
const { errorHandler } = require('./middleware/errorHandler');

function createApp(options = {}) {
  if (!process.env.JWT_SECRET) {
    throw new Error('JWT_SECRET must be set before starting BookNest.');
  }
  const db = options.db || openDatabase(
    options.dbPath || process.env.DB_PATH || './data/booknest.sqlite'
  );
  const app = express();
  app.disable('x-powered-by');
  app.use(helmet());
  app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
  app.use(express.json({ limit: '32kb' }));
  app.use(morgan('combined'));
  app.get('/api/health', (req, res) => res.json({ status: 'ok' }));
  app.use('/api', createApiRouter(db));
  app.use((req, res, next) => {
    const { AppError } = require('./utils/errors');
    next(new AppError(404, 'NOT_FOUND', 'The requested endpoint was not found.'));
  });
  app.use(errorHandler);
  app.locals.db = db;
  return app;
}

module.exports = { createApp };
