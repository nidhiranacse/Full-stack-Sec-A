const path = require('node:path');
require('dotenv').config({ path: path.resolve(__dirname, '../../.env') });
const { createApp } = require('./app');

const app = createApp();
const port = Number(process.env.PORT) || 3000;
app.listen(port, () => {
  console.log(`BookNest API listening on port ${port}`);
});
