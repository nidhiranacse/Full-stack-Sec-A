const request = require('supertest');
const bcrypt = require('bcryptjs');
const { createApp } = require('../src/app');
const { initializeDatabase } = require('../src/db/schema');

let app;
let db;
let librarianToken;
let memberToken;

function seedTestDatabase() {
  db.exec('DELETE FROM issues; DELETE FROM books; DELETE FROM members;');
  const hash = bcrypt.hashSync('Pass@123', 4);
  const member = db.prepare(
    'INSERT INTO members (id, name, email, password_hash, role) VALUES (?, ?, ?, ?, ?)'
  );
  [
    [1, 'Admin', 'admin@lib.example', hash, 'librarian'],
    [2, 'Aarav', 'aarav@lib.example', hash, 'member'],
    [3, 'Meera', 'meera@lib.example', hash, 'member'],
    [4, 'Rohan', 'rohan@lib.example', hash, 'member']
  ].forEach((row) => member.run(...row));
  const book = db.prepare(
    'INSERT INTO books (id, code, title, author, total_copies, available_copies) VALUES (?, ?, ?, ?, ?, ?)'
  );
  [
    [1, 'LIB-1001', 'The Pragmatic Programmer', 'Hunt & Thomas', 2, 2],
    [2, 'LIB-1002', 'Clean Code', 'Robert C. Martin', 1, 1],
    [3, 'LIB-1003', 'Operating System Concepts', 'Silberschatz', 3, 3],
    [4, 'LIB-1004', 'Database System Concepts', 'Silberschatz', 1, 0],
    [5, 'LIB-1005', 'Computer Networks', 'Tanenbaum', 2, 2]
  ].forEach((row) => book.run(...row));
  const overdueIssued = new Date();
  overdueIssued.setDate(overdueIssued.getDate() - 20);
  const overdueDue = new Date();
  overdueDue.setDate(overdueDue.getDate() - 6);
  db.prepare(
    'INSERT INTO issues (id, member_id, book_id, issued_on, due_on) VALUES (1, 4, 4, ?, ?)'
  ).run(overdueIssued.toISOString().slice(0, 10), overdueDue.toISOString().slice(0, 10));
}

beforeEach(async () => {
  process.env.JWT_SECRET = 'test-only-secret';
  db = require('better-sqlite3')(':memory:');
  db.pragma('foreign_keys = ON');
  initializeDatabase(db);
  seedTestDatabase();
  app = createApp({ db });
  const admin = await request(app).post('/api/auth/login')
    .send({ email: 'admin@lib.example', password: 'Pass@123' });
  const member = await request(app).post('/api/auth/login')
    .send({ email: 'aarav@lib.example', password: 'Pass@123' });
  librarianToken = admin.body.token;
  memberToken = member.body.token;
});

afterEach(() => db.close());

describe('BookNest API', () => {
  test('rejects a wrong password', async () => {
    const response = await request(app).post('/api/auth/login')
      .send({ email: 'admin@lib.example', password: 'wrong' });
    expect(response.status).toBe(401);
  });

  test('rejects unauthenticated catalogue access', async () => {
    expect((await request(app).get('/api/books')).status).toBe(401);
  });

  test('parameterises catalogue search and returns pagination metadata', async () => {
    const page = await request(app).get('/api/books?page=2&limit=2')
      .set('Authorization', `Bearer ${memberToken}`);
    expect(page.body.data.map((book) => book.id)).toEqual([3, 4]);
    expect(page.body).toMatchObject({ total: 5, totalPages: 3 });
    const search = await request(app).get("/api/books?search=' OR '1'='1")
      .set('Authorization', `Bearer ${memberToken}`);
    expect(search.body.total).toBe(0);
  });

  test('issues the last copy once and rejects the next request', async () => {
    const first = await request(app).post('/api/issues')
      .set('Authorization', `Bearer ${librarianToken}`).send({ memberId: 2, bookId: 2 });
    const second = await request(app).post('/api/issues')
      .set('Authorization', `Bearer ${librarianToken}`).send({ memberId: 3, bookId: 2 });
    expect(first.status).toBe(201);
    expect(second.status).toBe(409);
    expect(second.body.error.code).toBe('NO_COPIES');
    expect(db.prepare('SELECT available_copies FROM books WHERE id = 2').get().available_copies).toBe(0);
  });

  test('rejects a fourth active issue', async () => {
    for (const bookId of [1, 3, 5]) {
      expect((await request(app).post('/api/issues')
        .set('Authorization', `Bearer ${librarianToken}`)
        .send({ memberId: 2, bookId })).status).toBe(201);
    }
    const fourth = await request(app).post('/api/issues')
      .set('Authorization', `Bearer ${librarianToken}`).send({ memberId: 2, bookId: 2 });
    expect(fourth.status).toBe(409);
    expect(fourth.body.error.code).toBe('LIMIT_REACHED');
  });

  test('returns the overdue seed issue with a fine of 12', async () => {
    const returned = await request(app).post('/api/issues/1/return')
      .set('Authorization', `Bearer ${librarianToken}`);
    expect(returned.body.fine).toBe(12);
    expect(db.prepare('SELECT available_copies FROM books WHERE id = 4').get().available_copies).toBe(1);
    const again = await request(app).post('/api/issues/1/return')
      .set('Authorization', `Bearer ${librarianToken}`);
    expect(again.status).toBe(409);
    expect(again.body.error.code).toBe('ALREADY_RETURNED');
  });

  test('limits overdue access to librarians and validates issue bodies', async () => {
    const forbidden = await request(app).get('/api/issues/overdue')
      .set('Authorization', `Bearer ${memberToken}`);
    expect(forbidden.status).toBe(403);
    const invalid = await request(app).post('/api/issues')
      .set('Authorization', `Bearer ${librarianToken}`).send({});
    expect(invalid.status).toBe(400);
    expect(invalid.body.error.code).toBe('VALIDATION_ERROR');
  });

  test('serializes simultaneous requests for the last copy', async () => {
    const responses = await Promise.all([
      request(app).post('/api/issues').set('Authorization', `Bearer ${librarianToken}`)
        .send({ memberId: 2, bookId: 2 }),
      request(app).post('/api/issues').set('Authorization', `Bearer ${librarianToken}`)
        .send({ memberId: 3, bookId: 2 })
    ]);
    expect(responses.map((response) => response.status).sort()).toEqual([201, 409]);
  });
});
