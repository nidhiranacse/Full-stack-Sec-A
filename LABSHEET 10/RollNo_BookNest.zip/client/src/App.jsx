import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import { api, clearSession, getSession, postJson, saveSession, setUnauthorizedHandler } from './api.js';

function Alert({ children, success = false }) {
  if (!children) return null;
  return <div className={`alert ${success ? 'alert-success' : ''}`} role="status">{children}</div>;
}

function Loading() {
  return <div className="loading"><span className="spinner" />Loading your library…</div>;
}

function Empty({ children }) {
  return <div className="empty-state"><span className="empty-icon">✳</span><p>{children}</p></div>;
}

function App() {
  const [session, setSession] = useState(() => getSession());
  const navigate = useNavigate();
  const location = useLocation();

  const logout = useCallback(() => {
    clearSession();
    setSession(null);
    navigate('/login');
  }, [navigate]);

  useEffect(() => setUnauthorizedHandler(logout), [logout]);

  const login = (value) => {
    saveSession(value);
    setSession(value);
    navigate(value.user.role === 'librarian' ? '/' : '/');
  };

  return (
    <div className="app-shell">
      {session && <Header session={session} logout={logout} location={location} />}
      <Routes>
        <Route path="/login" element={session ? <Navigate to="/" replace /> : <Login onLogin={login} />} />
        <Route path="/" element={<Protected session={session}><Catalogue session={session} /></Protected>} />
        <Route path="/my-issues" element={<Protected session={session} role="member"><MyIssues /></Protected>} />
        <Route path="/librarian" element={<Protected session={session} role="librarian"><Librarian /></Protected>} />
        <Route path="*" element={<Navigate to={session ? '/' : '/login'} replace />} />
      </Routes>
      <footer className="site-footer"><span>BOOKNEST LIBRARY</span><span>Good books. Good company.</span></footer>
    </div>
  );
}

function Header({ session, logout, location }) {
  return (
    <header className="topbar">
      <Link className="brand" to="/" aria-label="BookNest home">
        <span className="brand-mark">B<span>.</span></span>
        <span className="brand-name">booknest<small>THE COLLEGE LIBRARY</small></span>
      </Link>
      <nav className="topnav">
        <Link className={location.pathname === '/' ? 'active' : ''} to="/">Catalogue</Link>
        {session.user.role === 'member'
          ? <Link className={location.pathname === '/my-issues' ? 'active' : ''} to="/my-issues">My issues</Link>
          : <Link className={location.pathname === '/librarian' ? 'active' : ''} to="/librarian">Librarian desk</Link>}
      </nav>
      <div className="account">
        <span className="account-name">{session.user.name}<small>{session.user.role}</small></span>
        <button className="logout-button" onClick={logout} title="Sign out" aria-label="Log out">↗</button>
      </div>
    </header>
  );
}

function Protected({ session, role, children }) {
  if (!session) return <Navigate to="/login" replace />;
  if (role && session.user.role !== role) return <Navigate to="/" replace />;
  return children;
}

function Login({ onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setError('');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError('Please enter a valid email address.');
      return;
    }
    if (password.length < 1) {
      setError('Please enter your password.');
      return;
    }
    setBusy(true);
    try {
      onLogin(await postJson('/auth/login', { email: email.trim(), password }));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="login-layout">
      <section className="login-art">
        <div className="art-topline"><span>EST. FOR THE CURIOUS</span><span>01 / 05</span></div>
        <div className="book-illustration" aria-hidden="true">
          <div className="book book-back"><span>IDEAS<br />THAT LAST</span></div>
          <div className="book book-front"><i>THE ART OF</i><strong>READING<br />WELL</strong><span>BOOKNEST EDITION · VOL. I</span></div>
          <div className="book-shadow" />
        </div>
        <div className="art-caption"><span>01 — A QUIETER KIND OF DISCOVERY</span><strong>Find your next<br />favourite chapter.</strong></div>
        <div className="art-decoration">READ<br />MORE<br />WONDER.</div>
      </section>
      <section className="login-panel">
        <div className="login-form-wrap">
          <div className="eyebrow"><span /> YOUR LIBRARY, REOPENED</div>
          <h1>Welcome<br />back<span className="yellow-dot">.</span></h1>
          <p className="login-intro">Sign in to browse the shelves and keep your reading life in order.</p>
          <form className="login-form" onSubmit={submit}>
            <label htmlFor="email">EMAIL ADDRESS</label>
            <input id="email" type="email" autoComplete="username" placeholder="you@college.edu" value={email} onChange={(e) => setEmail(e.target.value)} required />
            <label htmlFor="password">PASSWORD</label>
            <input id="password" type="password" autoComplete="current-password" placeholder="Your password" value={password} onChange={(e) => setPassword(e.target.value)} required />
            <Alert>{error}</Alert>
            <button className="button button-dark login-submit" disabled={busy}>{busy ? 'Opening the doors…' : 'Enter the library'} <span>↗</span></button>
          </form>
          <div className="login-note"><span>✳</span> A little room for big ideas.</div>
        </div>
        <div className="login-bottom"><span>BOOKNEST · COLLEGE LIBRARY</span><span>EST. 2025</span></div>
      </section>
    </main>
  );
}

function Catalogue({ session }) {
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [page, setPage] = useState(1);
  const [result, setResult] = useState({ data: [], page: 1, limit: 8, total: 0, totalPages: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => {
      setPage(1);
      setDebouncedSearch(search.trim());
    }, 300);
    return () => clearTimeout(timer);
  }, [search]);

  const loadBooks = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const params = new URLSearchParams({ search: debouncedSearch, page: String(page), limit: '8' });
      setResult(await api(`/books?${params}`));
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [debouncedSearch, page]);

  useEffect(() => { loadBooks(); }, [loadBooks]);

  return (
    <main className="page-content">
      <div className="page-heading">
        <div><div className="eyebrow"><span /> THE COLLECTION</div><h1>A good book<br />finds its <em>way.</em></h1></div>
        <p className="heading-aside">A small collection for<br />a world of big ideas.<br /><b>{result.total} titles on our shelves</b></p>
      </div>
      <section className="catalogue-section">
        <div className="section-bar">
          <div><span className="section-index">01</span><h2>The shelves</h2></div>
          <label className="search-box"><span aria-hidden="true">⌕</span><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Find a title or author…" aria-label="Search books by title or author" />{search && <button onClick={() => setSearch('')} aria-label="Clear search">×</button>}</label>
        </div>
        <Alert>{error}</Alert>
        {loading ? <Loading /> : result.data.length === 0 ? <Empty>{debouncedSearch ? 'No books found. Try another title or author.' : 'The shelves are waiting for their first books.'}</Empty> : (
          <div className="book-grid">
            {result.data.map((book, index) => <BookCard key={book.id} book={book} index={(page - 1) * result.limit + index + 1} />)}
          </div>
        )}
        {!loading && result.total > 0 && <div className="pagination">
          <span>SHOWING <b>{(page - 1) * result.limit + 1}–{Math.min(page * result.limit, result.total)}</b> OF <b>{result.total}</b></span>
          <div><button className="page-button" disabled={page <= 1} onClick={() => setPage((value) => value - 1)}>← <span>Previous</span></button><span className="page-count">{result.page} / {Math.max(result.totalPages, 1)}</span><button className="page-button" disabled={page >= result.totalPages} onClick={() => setPage((value) => value + 1)}><span>Next</span> →</button></div>
        </div>}
      </section>
      {session.user.role === 'librarian' && <div className="librarian-shortcut"><span>LIBRARIAN ACCESS</span><p>Ready to help a reader find their next book?</p><Link className="text-link" to="/librarian">Open librarian desk <b>↗</b></Link></div>}
    </main>
  );
}

const coverStyles = ['cover-gold', 'cover-cream', 'cover-dark', 'cover-yellow', 'cover-olive'];

function BookCard({ book, index }) {
  const style = coverStyles[(book.id - 1) % coverStyles.length];
  return (
    <article className="book-card">
      <div className={`cover ${style}`}>
        <span className="cover-code">{book.code}</span>
        <span className="cover-number">{String(book.id).padStart(2, '0')}</span>
        <div className="cover-art" aria-hidden="true"><i /><i /><i /></div>
        <strong>{book.title}</strong>
        <span className="cover-author">{book.author}</span>
        <span className="cover-imprint">BOOKNEST LIBRARY</span>
      </div>
      <div className="book-info">
        <div><span className="book-order">NO. {String(index).padStart(2, '0')}</span><h3>{book.title}</h3><p>{book.author}</p></div>
        <span className={`availability ${book.availableCopies > 0 ? '' : 'unavailable'}`}><i />{book.availableCopies > 0 ? `${book.availableCopies} available` : 'On loan'}</span>
      </div>
    </article>
  );
}

function MyIssues() {
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  useEffect(() => {
    api('/issues/mine').then(setIssues).catch((err) => setError(err.message)).finally(() => setLoading(false));
  }, []);
  const activeCount = useMemo(() => issues.filter((issue) => !issue.returnedOn).length, [issues]);
  return (
    <main className="page-content">
      <div className="page-heading compact-heading"><div><div className="eyebrow"><span /> YOUR READING LIST</div><h1>Kept on <em>loan.</em></h1></div><p className="heading-aside"><b>{activeCount} active {activeCount === 1 ? 'book' : 'books'}</b><br />Your current borrowed books.</p></div>
      <section className="catalogue-section">
        <div className="section-bar"><div><span className="section-index">02</span><h2>My issues</h2></div></div>
        <Alert>{error}</Alert>
        {loading ? <Loading /> : issues.length === 0 ? <Empty>No issues yet. A new favourite is waiting on the shelves.</Empty> : (
          <div className="issues-list">
            {issues.map((issue) => <article key={issue.id} className="issue-row">
              <span className="issue-number">{String(issue.id).padStart(2, '0')}</span>
              <div className="issue-title"><h3>{issue.bookTitle}</h3><p>{issue.author} · {issue.bookCode}</p></div>
              <div className="issue-date"><span>DUE DATE</span><b>{issue.dueOn}</b></div>
              <div className={`issue-status ${issue.returnedOn ? 'returned' : ''}`}><i />{issue.returnedOn ? `Returned ${issue.returnedOn}` : 'On loan'}</div>
              {!issue.returnedOn && issue.currentFine > 0 && <span className="fine-pill">₹{issue.currentFine} accrued</span>}
            </article>)}
          </div>
        )}
      </section>
    </main>
  );
}

function Librarian() {
  const [members, setMembers] = useState([]);
  const [books, setBooks] = useState([]);
  const [overdue, setOverdue] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [memberId, setMemberId] = useState('');
  const [bookId, setBookId] = useState('');
  const [busy, setBusy] = useState(false);
  const [bookForm, setBookForm] = useState({ code: '', title: '', author: '', totalCopies: '1' });
  const availableBooks = useMemo(() => books.filter((book) => book.availableCopies > 0), [books]);

  const loadDesk = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const [memberData, bookData, overdueData] = await Promise.all([
        api('/members'),
        api('/books?page=1&limit=50'),
        api('/issues/overdue')
      ]);
      setMembers(memberData);
      setBooks(bookData.data);
      setOverdue(overdueData);
      setMemberId((current) => current || String(memberData[0]?.id || ''));
      setBookId((current) => current || String(bookData.data.find((book) => book.availableCopies > 0)?.id || ''));
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => { loadDesk(); }, [loadDesk]);

  async function submitIssue(event) {
    event.preventDefault();
    setError('');
    setNotice('');
    setBusy(true);
    try {
      const issued = await postJson('/issues', { memberId: Number(memberId), bookId: Number(bookId) });
      setNotice(`Issue #${issued.id} recorded. Due ${issued.dueOn}.`);
      await loadDesk();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function submitBook(event) {
    event.preventDefault();
    setError('');
    setNotice('');
    setBusy(true);
    try {
      const book = await postJson('/books', { ...bookForm, totalCopies: Number(bookForm.totalCopies) });
      setNotice(`${book.title} added to the shelves.`);
      setBookForm({ code: '', title: '', author: '', totalCopies: '1' });
      await loadDesk();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function returnIssue(issue) {
    setError('');
    setNotice('');
    try {
      const result = await postJson(`/issues/${issue.id}/return`, {});
      setNotice(`Returned “${issue.bookTitle}”. Fine charged: ₹${result.fine}.`);
      await loadDesk();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <main className="page-content">
      <div className="page-heading compact-heading"><div><div className="eyebrow"><span /> THE LIBRARIAN'S DESK</div><h1>Keep the shelves<br /><em>turning.</em></h1></div><p className="heading-aside">Issue a new story.<br />Bring a good one home.</p></div>
      <Alert>{error}</Alert><Alert success>{notice}</Alert>
      <div className="desk-grid">
        <section className="desk-panel">
          <div className="section-bar"><div><span className="section-index">01</span><h2>Issue a book</h2></div></div>
          <p className="panel-intro">Fourteen days to disappear into a good story.</p>
          <form className="desk-form" onSubmit={submitIssue}>
            <label htmlFor="member">MEMBER</label>
            <select id="member" required value={memberId} onChange={(e) => setMemberId(e.target.value)}><option value="">Choose a member</option>{members.map((member) => <option key={member.id} value={member.id}>{member.name} · {member.email}</option>)}</select>
            <label htmlFor="book">BOOK</label>
            <select id="book" required value={bookId} onChange={(e) => setBookId(e.target.value)}><option value="">Choose an available book</option>{availableBooks.map((book) => <option key={book.id} value={book.id}>{book.title} · {book.availableCopies} available</option>)}</select>
            <button className="button button-dark" disabled={busy || loading || !availableBooks.length}>{busy ? 'Recording…' : 'Record issue'} <span>↗</span></button>
          </form>
          {!loading && !availableBooks.length && <p className="inline-note">No books are currently available to issue.</p>}
        </section>
        <section className="desk-panel add-book-panel">
          <div className="section-bar"><div><span className="section-index">02</span><h2>Add to shelves</h2></div></div>
          <p className="panel-intro">Make room for another good idea.</p>
          <form className="desk-form" onSubmit={submitBook}>
            <label htmlFor="code">BOOK CODE</label><input id="code" required value={bookForm.code} onChange={(e) => setBookForm({ ...bookForm, code: e.target.value })} placeholder="LIB-1006" />
            <label htmlFor="title">TITLE</label><input id="title" required value={bookForm.title} onChange={(e) => setBookForm({ ...bookForm, title: e.target.value })} placeholder="A book worth sharing" />
            <label htmlFor="author">AUTHOR</label><input id="author" required value={bookForm.author} onChange={(e) => setBookForm({ ...bookForm, author: e.target.value })} placeholder="Author name" />
            <label htmlFor="copies">TOTAL COPIES</label><input id="copies" required type="number" min="0" step="1" value={bookForm.totalCopies} onChange={(e) => setBookForm({ ...bookForm, totalCopies: e.target.value })} />
            <button className="button button-outline" disabled={busy}>{busy ? 'Saving…' : 'Add book'} <span>↗</span></button>
          </form>
        </section>
      </div>
      <section className="catalogue-section overdue-section">
        <div className="section-bar"><div><span className="section-index">03</span><h2>Overdue returns</h2></div><span className="record-count">{overdue.length} {overdue.length === 1 ? 'BOOK' : 'BOOKS'}</span></div>
        {loading ? <Loading /> : overdue.length === 0 ? <Empty>All caught up. Every book is right where it belongs.</Empty> : (
          <div className="overdue-table-wrap"><table className="overdue-table">
            <thead><tr><th>MEMBER</th><th>BOOK</th><th>OVERDUE</th><th>FINE</th><th> </th></tr></thead>
            <tbody>{overdue.map((issue) => <tr key={issue.id}>
              <td><strong>{issue.memberName}</strong><small>{issue.memberEmail}</small></td>
              <td><strong>{issue.bookTitle}</strong><small>{issue.bookCode}</small></td>
              <td><span className="late-tag">{issue.daysOverdue} days</span></td>
              <td className="fine-value">₹{issue.fine}</td>
              <td><button className="return-button" onClick={() => returnIssue(issue)}>Return <span>↗</span></button></td>
            </tr>)}</tbody>
          </table></div>
        )}
      </section>
    </main>
  );
}

export default App;
